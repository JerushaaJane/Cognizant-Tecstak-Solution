
public interface IRepair {
	
	void ProcessPhoneRepair(String modelName);

	void ProcessAccessoryRepair(String accessoryType);
}
