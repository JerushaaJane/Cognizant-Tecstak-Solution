
public class ChickenBurger extends Burger {

	@Override
	public String name() {
		return "Chicken Burger";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 35.0f;
	}

}
