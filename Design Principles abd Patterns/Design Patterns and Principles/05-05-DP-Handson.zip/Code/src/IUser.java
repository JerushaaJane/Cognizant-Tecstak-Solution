
public interface IUser {

	void RecieveMessage(String message);

	void SendMessage(String message);
}
