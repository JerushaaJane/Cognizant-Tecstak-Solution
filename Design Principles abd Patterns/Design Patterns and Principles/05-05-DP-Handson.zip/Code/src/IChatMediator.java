
public interface IChatMediator {

	void AddUser(IUser name);

	void SendMessage(String message);
}
